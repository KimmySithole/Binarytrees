from itertools import islice
import os

lines=[]
start = 991
end = 9910
increment=991

for x in range(start,end,increment):
	print("test for :" + str(x))
	f1=open("fileout"+str(x)+ ".txt","w");
	name = os.path.basename(f1.name)
	with open("data/vaccinations.csv","r") as vaccinations:
		lines= list(islice(vaccinations,x))
		
	with open("data/vaccinationsNew.csv","w") as vaccinationsNew:
		for y in lines:
			vaccinationsNew.write(y)
	for a in range(x):
		f=open("inputfile.csv","w+")
		line=lines[a].split(",")
		input=line[1],line[0]
		f.write(line[1]+"\n"+line[0]+"\n\n")
		#change from VaccineBSTApp to VaccineArrayApp when wanting to automate for the arrayapp
		os.system("java -cp bin VaccineBSTApp Testing < inputfile.csv")
		f.close
