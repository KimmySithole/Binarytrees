/**
* <h1>Vaccine Data Structure</h1>
* The Vaccine program stores Vaccine data associated with a country and date together with number of vaccinations for each country of a specific date
*<p>
*Comparable<Vaccine> is implemented to compare the data structures of Vaccination
*
* @author  Kimmy Sithole
* @version 1.0
* @since   2022-03-05
*/
public class Vaccine implements Comparable<Vaccine>
{
    String country;
    String date;
    String vaccinations;
    	 /**
   * This method is the constructor which is used to initiate the String Variable.
   * @param line is the parameter holding the country name and date and number of vaccinations.
   * @return Nothing.
   */	
    
    public Vaccine ( String line)
    {
        String [] parts = line.split (",");
        country=parts[0];
        date= parts[1];
        if (parts.length==3)
            vaccinations=parts[2];
        else
            vaccinations="0";
        
    }
    
    /**
   * This method is the compareTo method which is used to compare the Vaccine objects.
   * @param v This is the paramter of Vaccine type.
   * 
   * @return int This returns the integer depending on the comparison. For example: 0 will be returned if the comparison keys are equal
   */
    
     public int compareTo(Vaccine v)
     {
         return (country+date).compareTo(v.country+v.date);
     }
     
}
