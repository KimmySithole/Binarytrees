/**
* <h1>VaccineArray Data Structure</h1>
* The VaccineArray program implements an application that simply stores Vaccine data  into an Array creating a data structure of vaccines
* <p>
*
* @author  Kimmy Sithole
* @version 1.0
* @since   2022-03-05
*/
public class VaccineArray
{
    Counter opCount= new Counter();
    Vaccine[] data = new Vaccine[10000];
    int records = 0;
    /**
     * Add Vaccine Data to an Array data structure created
     * @param v This is a parameter of Vaccine type
     */
    public void add ( Vaccine v)
    {
        data[records]= v;
        records++;
    }
    /**
   * This is the finder method is used to find the vaccination  v passed on and see if it is in the data structure created in the class.
   * The vaccination number is found by looping through the array of Vaccine objects. 
   * @param v a Vaccine object we are searching for.
   * @return Vaccine This returns the vaccination object if fond as it will return a null pointer.
   */
    public Vaccine find ( Vaccine v1)
    {
        int count=0;
        opCount.add();
        while (data[count].compareTo(v1)!=0 && records>=count && data[count]!=null)
        {
           	opCount.add();
            count++;
        }
        if (count>records)
        {
            return null ;
            
        }
        else
        {
            return data[count];
        }
    }
}
