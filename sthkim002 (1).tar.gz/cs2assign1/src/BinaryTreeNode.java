// Hussein's Binary Tree
// 26 March 2017
// Hussein Suleman

public class BinaryTreeNode<Vaccine>
{
   Vaccine data;
   BinaryTreeNode<Vaccine> left;
   BinaryTreeNode<Vaccine> right;
   
   public BinaryTreeNode ( Vaccine d, BinaryTreeNode<Vaccine> l, BinaryTreeNode<Vaccine> r )
   {
      data = d;
      left = l;
      right = r;
   }
   
   BinaryTreeNode<Vaccine> getLeft () { return left; }
   BinaryTreeNode<Vaccine> getRight () { return right; }
}
