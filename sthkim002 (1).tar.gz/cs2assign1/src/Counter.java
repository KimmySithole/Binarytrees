/**
* <h1> Counter Class </h1>
* Helps to create counter for the number of operations done for search and insert   
*<p>
*
* @author  Kimmy Sithole.
* @version 1.0.
* @since   2022-03-08.
*/

public class Counter
{
    int opCount;
    public Counter()
    {
        opCount=0;
    }
      /**
   * This method increases the counter.
   * @param no parameter.
   * @return Nothing.
   */
    public int add()
    {
        return opCount++;
    }
     /**
   * This method increments the counter and returns the new Counter value.
   * @param no parameter.
   * @return Nothing.
   */
    public int value()
    {
        return opCount;
    }
     /**
   * This method returns the count value.
   * @param no parameter.
   * @return Nothing.
   */
}
