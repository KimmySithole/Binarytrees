from itertools import islice
import os

lines=[]
start = 0
end = 10
increment= 2

for x in range (start,end, increment):
	with open("finalOutput","r") as fp:
		lines= list(islice(fp,x))
		print(min(lines))
		print(max(lines))
		print(mean(lines))
	fp.seek()
	fp.writelines(lines[x:])
	
