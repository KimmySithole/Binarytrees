// Kimmy's Vaccine binary search tree
import java.util.*;
import java.io.*;

/**
* <h1>VaccineBSTApp Data Structure</h1>
* The VaccineBSTAPP program implements an application which reads in a file containing countries and dates together with vaccines done on a particular date in a specific country. The user inputs a date and a country and the app will output the vaccines done in that country ,on that date if the input is valid.   
*<p>
*
* @author  Kimmy Sithole.
* @version 1.0.
* @since   2022-03-05.
*/

public class VaccineBSTApp
{
	 /**
   * This method is used to read a csv file using the Scanner class and store the data in a BinarySearchTree.
   * This method is also used to interact with the user. The user enters an input and the method stores them in an ArrayList then stops taking user 
   * input when there is a blank line as input.
   * The user input helps to create a key of "country + date" which assists in searching through the data from the vaccine.csv file. This will   
   * then return a vaccination when the key is found
   * @param None.
   * @return Nothing.
   * @param args Not used. 
   * @exception Exception reports FileNotFound Exception.
   * @see Exception.
   */
   //Comment out all the output except for the last output when using the pythone //script for experimentation
   public static void main ( String [] args )
   {
      BinarySearchTree<Vaccine> bt = new BinarySearchTree<Vaccine> ();
      // only change vaccinations.csv to vaccinationsNew.csv when automating the //prgram for experimentation of counting the search operations
      File f = new File("data/vaccinations.csv");
      try
      {
       Scanner sc=new Scanner(f);
       while (sc.hasNextLine())
       {
         String line = sc.nextLine();
         bt.insert(new Vaccine(line));
       }
      }
      catch (Exception e)
      {
        System.out.println("File not found"); 
      }
      Scanner sc1 =new Scanner(System.in);
      //System.out.println("Enter date:");
        String date=sc1.nextLine();
        String data;
        //System.out.println("Enter list of countries (end with an empty line):");
        String [] results = new String[100];
        int count=0;
        data="";
        while (sc1.hasNextLine())
        {
          String country= sc1.nextLine();
          data=country+","+date;
          Vaccine v=new Vaccine(data);
          
          if (bt.find(v)==null)
             results[count]="<Not Found>";
          else
             results[count]=(bt.find(v)).data.vaccinations;
         
          String output= country+" = "+results[count];
          System.out.println(output);
          count++;
         }  
       System.out.println("Number of operations:");
       System.out.println(bt.opCountsearch.value());
   }
}

