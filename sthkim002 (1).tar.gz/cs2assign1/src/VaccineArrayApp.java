import java.io.*;
import java.util.*;
/**
* <h1>VaccineArrayApp Data Structure</h1>
* The VaccineArrayApp program implements reads in a file containing countries and dates, together with vaccines done on a particular date in a specific country. The user inputs a date and a country and the app will output the vaccines done in that country and on that date if the input is valid.   
*<p>
*
* @author  Kimmy Sithole.
* @version 1.0.
* @since   2022-03-05.
*/
//Comment out all the output except for the last output when using the pythone script //for experimentation
class VaccineArrayApp
{
    VaccineArray va = new VaccineArray ();
    /**
   * This method is used to read CSV file using Scanner class which will then store the data in an array.
   * @param args a String array the hold the location of the file.
   * @return Nothing.
   * @exception Exception reports FileNotFound Exception.
   * @see Exception
   */
   // only change vaccinations.csv to vaccinationsNew.csv when automating the //prgram for experimentation of counting the search operations
    public void readInFile ()
    {
        File f= new File("data/vaccinations.csv");
        try
        {
            Scanner sc = new Scanner (f);
            while (sc.hasNextLine())
            {
                String line = sc.nextLine();
                va.add (new Vaccine (line));
            }
        }
        catch (Exception e)
        {
            System.out.println("File not found");
        }
            
    }
      /**
   * This method is used to interact with the user. The user enters an input and the app stores the info in an array as a vaccine object then    
   * stops taking user input 
   * when there is a blank line as input.
   * The user input helps to create a key of "country + date" which assists in searching through the data from the vaccine.csv file. This will   
   * then return a vaccination when the key is found
   * @param None.
   * @return Nothing.
   */
    public void userInterface()
    {
        Scanner sc1= new Scanner(System.in);
        System.out.println("Enter date:");
        String userdate=sc1.nextLine();
        System.out.println("Enter list of countries (end with an empty line):");
        String [] userCountry= new String[100];
        String [] results= new String[100];
        int count=0;
 
        while (sc1.hasNextLine())
        {
            userCountry[count]=sc1.nextLine();
            String compare= userCountry[count]+','+userdate+',';
            Vaccine v= new Vaccine(compare);
          try
          {
           if (va.find(v)!=null)
              results[count]=va.find(v).vaccinations;
              count++;
          }
          catch (Exception e)
          {
              results[count]="<Not Found>";
              count++;
          }
        }
        System.out.println("");
        System.out.println("Results:");
        for ( int i = 0; i<count; i++)
        {
           String output=userCountry[i]+" = "+results[i];
           System.out.println(output);
        }
        System.out.println("Number of operations:");
        System.out.println(va.opCount.value());
    }
       /**
   * This main method makes use of readInFile() and userInterface() methods.
   * @param args Not used.  
   * @return Nothing.
   */
    public static void main ( String [] args)
    {
        VaccineArrayApp vaa = new VaccineArrayApp();
        vaa.readInFile();
        vaa.userInterface();
    } 
}
